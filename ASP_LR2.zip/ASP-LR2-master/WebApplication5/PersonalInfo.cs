﻿namespace WebApplication4
{

    public class PersonalInfo
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Occupation { get; set; }
    }

}
